const {FileInfo} = require ("../model/file.model")
const User = require ("../model/user.model")
exports.Login = async (req,res)=>{    
    try {        
        const {username,password,id} = req.body;
        const user = await User.findOne({username:username,password:password});
        if(!user){
            return res.status(404).json({code:404,message: "Invalid Credentials"})
        }
        else{   
            user.loginToken = user.generateJWT();
            return res.status(200).json({code:200,message: "Login Successful",data:user})
        }
    } catch (error) {
        return res.status(500).json({code:500,message: error.message})
    }
}
exports.addFile = async (req,res)=>{
    console.log(req.files,'dffffffffff');
    try {
        
    } catch (error) {
        return res.status(500).json({code:500,message: error.message})
    }
}
exports.getFile = async (req,res)=>{
    console.log(req.files,rew.file,'dffffffffff');
    try {
        
    } catch (error) {
        return res.status(500).json({code:500,message: error.message})
    }
}
exports.editFile = async (req,res)=>{
    console.log(req.files,rew.file,'dffffffffff');
    try {
        
    } catch (error) {
        return res.status(500).json({code:500,message: error.message})
    }
}
exports.deleteFile = async (req,res)=>{
    console.log(req.files,rew.file,'dffffffffff');
    try {
        
    } catch (error) {
        return res.status(500).json({code:500,message: error.message})
    }
}