const passport = require('passport')

module.exports = function(req, res, next){
    passport.authenticate('hello', function (err, user){
        if (err || !user){
            res.status(403).send({
            error: "you dont have access to this resource"                
            })
        }else{
            req.user = user
            next()
        }
    })(req, res, next)
}