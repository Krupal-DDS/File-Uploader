const multer = require('multer');
const path = require('path');
const fs= require('fs');

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        console.log(file,"fielelel");
        if ("file" === file.fieldname) {
            const filePath = path.join(process.cwd(),"api","public", "file");

            if (fs.existsSync(filePath)) {
                cb(null, filePath);
            } else {
                fs.mkdirSync(filePath, {recursive: true});
                cb(null, filePath);
            }
        }        
    },
    filename: function (req, file, cb) {
        cb(
            null,
            file.fieldname + "-" + Date.now() + path.extname(file.originalname)
        );
    },
});
const upload = multer({
    storage: storage,
    fileFilter: function (req, file, callback) {
        var ext = path.extname(file.originalname);       
        callback(null, true)
    }
});
module.exports = upload
