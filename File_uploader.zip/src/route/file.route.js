const express = require('express');
const fileRouter = express.Router(); 
const upload = require("../middleware/upload.js")
const authenticate = require("../middleware/Authenticate");
const {addFile, getFile, editFile, deleteFile, Login} = require("../controller/file.controller");
// const passport = require('passport') ;
// require('../middleware/Jwt.js');

fileRouter.post("/login", Login);
fileRouter.post("/addFile",authenticate,upload.single("file"), addFile);
fileRouter.get("/getFile", getFile );
fileRouter.put("/editFile",upload.single("file"), editFile);
fileRouter.delete("/deleteFile", deleteFile);

module.exports = fileRouter;

